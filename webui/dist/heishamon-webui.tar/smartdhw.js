var smartDhwData = null;
var smartDhwBusy = false;
var smartDhwDirty = false;
var smartDhwRefreshPromise = null;
var smartDhwEscape = hmEscape,
  smartDhwPad = hmPad;
function smartDhwValue(value, unit) {
  return value === null || value === undefined
    ? "Unavailable"
    : Number(value).toFixed(1) + (unit || "");
}
function smartDhwStatus(message, isError) {
  var el = document.getElementById("smartDhwCommandStatus");
  el.textContent = message || "";
  el.style.color = isError ? "var(--red)" : "var(--text-muted)";
}
function smartDhwMarkDirty() {
  smartDhwDirty = true;
  smartDhwStatus("Unsaved changes", false);
}
function smartDhwSetControls(disabled) {
  document
    .querySelectorAll(".smart-dhw-page button,.smart-dhw-page input")
    .forEach(function (control) {
      control.disabled = disabled;
    });
}
function smartDhwFillConfig(config) {
  document.getElementById("smartDhwEnabled").checked = !!config.enabled;
  document.getElementById("smartDhwEveningEnabled").checked =
    !!config.eveningEnabled;
  document.getElementById("smartDhwEveningTime").value =
    smartDhwPad(config.eveningHour) + ":" + smartDhwPad(config.eveningMinute);
  document.getElementById("smartDhwEveningTemp").value = String(
    config.eveningTriggerTemp,
  );
  document.getElementById("smartDhwMorningEnabled").checked =
    !!config.morningEnabled;
  document.getElementById("smartDhwMorningTime").value =
    smartDhwPad(config.morningHour) + ":" + smartDhwPad(config.morningMinute);
  document.getElementById("smartDhwMorningTemp").value = String(
    config.morningTriggerTemp,
  );
  document.getElementById("smartDhwMinimumInterval").value = String(
    config.minimumIntervalMinutes,
  );
}
function smartDhwRender(data) {
  smartDhwData = data;
  var status = data.status || {};
  var state = document.getElementById("smartDhwState");
  state.textContent =
    (data.config.enabled ? "Enabled · " : "Disabled · ") +
    (status.state || "Unknown");
  state.className =
    "scheduler-status-value " +
    (status.state === "Error"
      ? "smart-dhw-state-error"
      : data.config.enabled
        ? "smart-dhw-state-active"
        : "");
  document.getElementById("smartDhwTemperature").textContent = smartDhwValue(
    status.dhwTemperature,
    " °C",
  );
  document.getElementById("smartDhwTarget").textContent = smartDhwValue(
    status.dhwTarget,
    " °C",
  );
  document.getElementById("smartDhwOperation").textContent =
    status.dhwOperationActive === null
      ? "Unavailable"
      : status.forceDhwActive
        ? "Force DHW active"
        : status.dhwOperationActive
          ? "DHW active"
          : "Idle";
  document.getElementById("smartDhwNextCheck").textContent =
    data.nextCheck && data.nextCheck.available
      ? data.nextCheck.time + " · " + data.nextCheck.reserve
      : "No enabled check";
  document.getElementById("smartDhwLastStart").textContent =
    status.lastSuccessfulStart || "Never";
  var last = data.events && data.events.length ? data.events[0] : null;
  document.getElementById("smartDhwLastDecision").textContent = last
    ? last.time +
      " · " +
      last.reserve +
      " -> " +
      last.result +
      " · " +
      last.detail
    : "No decision since boot";
  if (!smartDhwDirty) smartDhwFillConfig(data.config);
  var events = document.getElementById("smartDhwEvents");
  if (!data.events || !data.events.length) {
    events.innerHTML =
      "<tr><td colspan='4' class='scheduler-empty'>No Smart DHW decisions since boot.</td></tr>";
  } else {
    events.innerHTML = data.events
      .map(function (event) {
        return (
          '<tr><td class="scheduler-mono">' +
          smartDhwEscape(event.time) +
          "</td><td>" +
          smartDhwEscape(event.reserve) +
          '</td><td class="scheduler-event-result">' +
          smartDhwEscape(event.result) +
          "</td><td>" +
          smartDhwEscape(event.detail) +
          "</td></tr>"
        );
      })
      .join("");
  }
  smartDhwSetControls(smartDhwBusy);
}
function smartDhwRefresh() {
  if (smartDhwRefreshPromise) return smartDhwRefreshPromise;
  smartDhwRefreshPromise = fetch("/smartdhwapi", { cache: "no-store" })
    .then(function (response) {
      if (!response.ok) throw new Error("HTTP " + response.status);
      return response.json();
    })
    .then(function (data) {
      smartDhwRefreshPromise = null;
      smartDhwRender(data);
      return data;
    })
    .catch(function (error) {
      smartDhwRefreshPromise = null;
      smartDhwStatus("Refresh failed: " + error.message, true);
      throw error;
    });
  return smartDhwRefreshPromise;
}
function smartDhwCommand(name, value) {
  if (smartDhwBusy) {
    smartDhwStatus("Please wait for the current command.", false);
    return Promise.reject(new Error("busy"));
  }
  smartDhwBusy = true;
  smartDhwSetControls(true);
  return fetch(
    "/smartdhwcommand?" +
      encodeURIComponent(name) +
      "=" +
      encodeURIComponent(value),
    { cache: "no-store" },
  )
    .then(function (response) {
      if (!response.ok) throw new Error("HTTP " + response.status);
      return response.text();
    })
    .then(function (message) {
      if (/^ERROR:/m.test(message))
        throw new Error(message.replace(/^ERROR:\s*/, "").trim());
      smartDhwStatus(message.replace(/^OK:\s*/, "").trim() || "Done", false);
      return smartDhwRefresh();
    })
    .then(function (data) {
      smartDhwBusy = false;
      smartDhwRender(data);
      return data;
    })
    .catch(function (error) {
      smartDhwBusy = false;
      smartDhwSetControls(false);
      if (error.message !== "busy")
        smartDhwStatus("Command failed: " + error.message, true);
      throw error;
    });
}
function smartDhwReadTime(id) {
  var value = document.getElementById(id).value;
  if (!/^\d{2}:\d{2}$/.test(value)) return null;
  var parts = value.split(":");
  var hour = Number(parts[0]);
  var minute = Number(parts[1]);
  return Number.isInteger(hour) &&
    hour >= 0 &&
    hour <= 23 &&
    Number.isInteger(minute) &&
    minute >= 0 &&
    minute <= 59
    ? { hour: hour, minute: minute }
    : null;
}
function smartDhwSave() {
  var evening = smartDhwReadTime("smartDhwEveningTime");
  var morning = smartDhwReadTime("smartDhwMorningTime");
  var eveningTemp = Number(
    document.getElementById("smartDhwEveningTemp").value,
  );
  var morningTemp = Number(
    document.getElementById("smartDhwMorningTemp").value,
  );
  var interval = Number(
    document.getElementById("smartDhwMinimumInterval").value,
  );
  if (!evening || !morning) {
    smartDhwStatus("Both check times must be valid.", true);
    return;
  }
  if (
    !Number.isFinite(eveningTemp) ||
    eveningTemp < 20 ||
    eveningTemp > 75 ||
    !Number.isFinite(morningTemp) ||
    morningTemp < 20 ||
    morningTemp > 75
  ) {
    smartDhwStatus("Trigger temperatures must be between 20 and 75 °C.", true);
    return;
  }
  if (!Number.isInteger(interval) || interval < 15 || interval > 1440) {
    smartDhwStatus("Minimum interval must be 15 to 1440 minutes.", true);
    return;
  }
  var config = {
    enabled: document.getElementById("smartDhwEnabled").checked,
    eveningEnabled: document.getElementById("smartDhwEveningEnabled").checked,
    eveningHour: evening.hour,
    eveningMinute: evening.minute,
    eveningTriggerTemp: eveningTemp,
    morningEnabled: document.getElementById("smartDhwMorningEnabled").checked,
    morningHour: morning.hour,
    morningMinute: morning.minute,
    morningTriggerTemp: morningTemp,
    minimumIntervalMinutes: interval,
  };
  smartDhwCommand("save", JSON.stringify(config)).then(function () {
    smartDhwDirty = false;
    smartDhwFillConfig(smartDhwData.config);
  });
}
function smartDhwCancel() {
  if (smartDhwData) {
    smartDhwDirty = false;
    smartDhwFillConfig(smartDhwData.config);
    smartDhwStatus("Changes discarded", false);
  }
}
function smartDhwTest(slot) {
  if (smartDhwDirty) {
    smartDhwStatus("Save or cancel pending edits before testing.", true);
    return;
  }
  smartDhwCommand("test", slot);
}
document.addEventListener("DOMContentLoaded", function () {
  smartDhwRefresh();
  window.setInterval(smartDhwRefresh, 10000);
});
